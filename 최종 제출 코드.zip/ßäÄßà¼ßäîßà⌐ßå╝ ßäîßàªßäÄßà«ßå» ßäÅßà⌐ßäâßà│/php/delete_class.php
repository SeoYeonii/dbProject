<!DOCTYPE html>
<html>

<head>
  <meta charset=utf-8>
  <meta name=viewport content="width=device-width,initial-scale=1">
  <link href=https://use.fontawesome.com/releases/v5.0.7/css/all.css rel=stylesheet>
</head>


<body>
  <div align='center'>
  <span>과목 삭제하기</span>

  <form method='get' action='delete_class_action.php'>
    <p>과목 이름: <input name="name" type="text"></p>
    <input type="submit" value="확인">
  </form>

  </div>

</body>

</html>
